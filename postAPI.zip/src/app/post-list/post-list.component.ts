import { Component } from '@angular/core';
import { ServiceAPIService } from '../service-api.service';
import { PostComponent } from '../post/post.component';

@Component({
  selector: 'app-post-list',
  imports: [PostComponent],
  templateUrl: './post-list.component.html',
  styleUrl: './post-list.component.css'
})

export class PostListComponent {
  posts: any[] = [];

  constructor(private apiService: ServiceAPIService) {
    this.apiService.getPosts().subscribe((data: any) => {
      this.posts = data;
    });
  }
}
